//
//  FSSWorkQueue.h
//  FluctSDK
//
//  Copyright © 2022 fluct, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern dispatch_queue_t FSSWorkQueue(void);

NS_ASSUME_NONNULL_END
